import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../shared/api.service';
import { UserModelSignup } from '../shared/model/user.model';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  public signupForm !: FormGroup;
  public signupObj = new UserModelSignup();

  constructor
  (
    private formBuilder : FormBuilder,
    private http : HttpClient,
    private router : Router, //navigate page to another page
    private api : ApiService
  ) { }


//Reactive active form
  ngOnInit(): void
  {
    this.signupForm = this.formBuilder.group({
      UserName:['',Validators.required],
      Password:['',Validators.required]
    })
  }

  signup()
  {
    this.signupObj.UserName = this.signupForm.value.UserName;
    this.signupObj.Password = this.signupForm.value.Password;

    this.api.signup(this.signupObj)
    .subscribe(res =>
      {
        alert(res.message);
        this.router.navigate(['login']);
        this.signupForm.reset();
      })

    //FAKE JSON SERVER API
    //this.http.post<any>("http://localhost:3000/signupUser",this.signupForm.value)
    //.subscribe(res =>
    //{
    //  alert("Signup Successfull");
    //  this.signupForm.reset();
    //  this.router.navigate(['login']);
    //}, err =>
    //{
    //  alert("Error Signing!")
    //})
  }



}
