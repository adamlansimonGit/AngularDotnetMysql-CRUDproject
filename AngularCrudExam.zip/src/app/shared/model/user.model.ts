export class UserModelSignup
{
  Id !: number;
  UserName !: string;
  Password !: string;
}
