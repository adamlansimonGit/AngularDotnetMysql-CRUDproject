import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http'
import { map } from 'rxjs/operators'


@Injectable({
  providedIn: 'root'
})
export class ApiService {

  public loginAPIUrl : string = "https://localhost:44320/api/Login/";
  public userAPIUrl : string = "https://localhost:44320/api/UserInfoRecord/";

  constructor(private _http : HttpClient) { }

  postUser(data : any)
  {
    return this._http.post<any>("http://localhost:3000/posts", data)
    .pipe(map((res:any)=>
    {
      return res;
    }))

  }

  deleteUser(id : number)
  {
    return this._http.delete<any>("http://localhost:3000/posts/"+id)
    .pipe(map((res:any)=>
    {
      return res;
    }))
  }

  updateuser(data : any, id : number)
  {
    return this._http.put<any>("http://localhost:3000/posts/"+id, data)
    .pipe(map((res:any)=>
    {
      return res;
    }))
  }

  getUser()
  {
    return this._http.get<any>(`${this.userAPIUrl}get_userinforecord`)
    .pipe(map((res:any)=>
    {
      return res;
    }))
  }

  signup(userObj : any)
  {
    //return this._http.post<any>(this.loginAPIUrl+"signup",userObj)
    return this._http.post<any>(`${this.loginAPIUrl}signup`,userObj)
  }

  login(userObj : any)
  {
    //return this._http.post<any>(this.loginAPIUrl+"signup",userObj)
    return this._http.post<any>(`${this.loginAPIUrl}login`,userObj)
  }

  //return this._http.get<any>("http://localhost:3000/posts/") //FAKE JASON API
}
