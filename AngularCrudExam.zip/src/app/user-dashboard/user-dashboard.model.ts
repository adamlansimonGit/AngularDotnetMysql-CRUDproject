export class UserModel
{
  id : number = 0;
  fullName : string = '';
  address : string = '';
  phoneNumber : string = '';
}
