import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from '../shared/api.service';
import { UserModel } from './user-dashboard.model';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})

export class UserDashboardComponent implements OnInit {

  formValue !: FormGroup;
  userModelObj : UserModel = new UserModel();
  userData !: any;
  showAdd !: boolean;
  showUpdate !: boolean;


  constructor(
    private formbuilder : FormBuilder,
    private api : ApiService) {}

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      fullName : [''],
      address : [''],
      phoneNumber : ['']
    })
    this.getAllUser();
  }

  clickAddUser()
  {
    this.formValue.reset();
    this.showAdd = true;
    this.showUpdate = false;
  }

  postUserDetails()
  {
    this.userModelObj.fullName = this.formValue.value.fullName;
    this.userModelObj.address = this.formValue.value.address;
    this.userModelObj.phoneNumber = this.formValue.value.phoneNumber;

    this.api.postUser(this.userModelObj)
    .subscribe(res=>
    {
      console.log(res);
      alert("User Added Succesfully")
      let ref = document.getElementById('cancel')
      ref?.click();
      this.formValue.reset();
      this.getAllUser();
    },
    err=>{
      alert("Something Went Wrong")
    })
  }

  getAllUser()
  {
    this.api.getUser()
    .subscribe(res =>
    {
      this.userData = res.userDetails;
    })
  }

  deleteUserRecord(row : any)
  {
    this.api.deleteUser(row.id)
    .subscribe(res =>
    {
      alert("User Deleted")
      this.getAllUser();
    })
  }

  editUserRecord(row : any)
  {
    this.showAdd = false;
    this.showUpdate = true;
    this.userModelObj.id = row.id;
    this.formValue.controls['fullName'].setValue(row.fullName);
    this.formValue.controls['address'].setValue(row.address);
    this.formValue.controls['phoneNumber'].setValue(row.phoneNumber);
  }

  updateUserDetails()
  {
    this.userModelObj.fullName = this.formValue.value.fullName;
    this.userModelObj.address = this.formValue.value.address;
    this.userModelObj.phoneNumber = this.formValue.value.phoneNumber;

    this.api.updateuser(this.userModelObj, this.userModelObj.id)
    .subscribe(res =>
    {
      alert("Update Successfull")
      let ref = document.getElementById('cancel')
      ref?.click();
      this.formValue.reset();
      this.getAllUser();
    })
  }
}

