﻿using Microsoft.EntityFrameworkCore;
using myExamCrudApi.Models;
using myExamCrudApi.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myExamCrudApi.Data
{
    public class UserDbContext : DbContext
    {
        //private static DbContextOptions options;

        public UserDbContext(DbContextOptions<UserDbContext>options):base(options)
        { 
            
        }

        public DbSet<UserLoginModel> UserLoginModels { get; set; }

        public DbSet<UserInfoRecordModel> UserInfoRecordModels { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserLoginModel>().ToTable("tbluserlogin");
            modelBuilder.Entity<UserInfoRecordModel>().ToTable("tbluserinforecord");

        }
    }
}
