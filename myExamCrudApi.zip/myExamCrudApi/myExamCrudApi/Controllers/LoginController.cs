﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using myExamCrudApi.Data;
using myExamCrudApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myExamCrudApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly UserDbContext _Context;

        public LoginController(UserDbContext userDbContext)
        {
            _Context = userDbContext;
        }

        [HttpGet("users")]
        public IActionResult GetUsers()
        {
            var userdetails = _Context.UserLoginModels.AsQueryable();
            return Ok(userdetails);
        }

        [HttpPost("signup")]
        public IActionResult SignUp([FromBody] UserLoginModel userObj)
        {
            if (userObj == null)
            {
                return BadRequest();
            }
            else
            {
                _Context.UserLoginModels.Add(userObj);
                _Context.SaveChanges();
                return Ok(new
                {
                    StatusCode = 200,
                    Message = "User Add Successfully"
                });
            }
        }
        [HttpPost("login")]

        public IActionResult Login([FromBody] UserLoginModel userObj)
        {
            if (userObj == null)
            {
                return BadRequest();
            }
            else 
            {
                var user = _Context.UserLoginModels.Where(a =>
                a.UserName == userObj.UserName
                && a.Password == userObj.Password).FirstOrDefault();
                if (user != null)
                {
                    return Ok(new
                    {
                        StatusCode = 200,
                        Message = "Logged In Success",
                        UserData = userObj.UserName
                    });
                }
                else 
                {
                    return NotFound(new
                    {
                        StatusCode = 404,
                        Message = "User not Found"
                    });
                }
            }
        }

    }
}
