﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using myExamCrudApi.Data;
using myExamCrudApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myExamCrudApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserInfoRecordController : ControllerBase
    {
        private readonly UserDbContext _Context;

        public UserInfoRecordController(UserDbContext userDbContext)
        {
            _Context = userDbContext;
        }

        [HttpPost("add_userinforecord")]

        public IActionResult AddUserInfoRecord([FromBody] UserInfoRecordModel userInfoRecordObj)
        {
            if (userInfoRecordObj == null)
            {
                return BadRequest();
            }
            else
            {
                _Context.UserInfoRecordModels.Add(userInfoRecordObj);
                _Context.SaveChanges();
                return Ok(new
                {
                    StatusCode = 200,
                    Message = "Employee added successfully"
                });
            }

        }

        [HttpPut("update_userinforecord")]

        public IActionResult UpdateUserInfoRecord([FromBody] UserInfoRecordModel userInfoRecordObj)
        {
            if (userInfoRecordObj == null)
            {
                return BadRequest();
            }

            var user = _Context.UserInfoRecordModels.AsNoTracking().FirstOrDefault(x => x.Id == userInfoRecordObj.Id);
            if (user == null)
            {
                return NotFound(new
                {
                    StatusCode = 404,
                    Message = "User Not Found"
                });
            }
            else
            {
                _Context.Entry(userInfoRecordObj).State = EntityState.Modified;
                _Context.SaveChanges();

                return Ok(new
                {
                    StatusCode = 200,
                    Message = "User Updated Successfully"
                });


            }
        }

        [HttpPut("delete_userinforecord/{id}")]

        public IActionResult DeleteUserInfoRecord(int id)
        {

            var user = _Context.UserInfoRecordModels.Find(id);


            if (user == null)
            {
                return NotFound(new
                {
                    StatusCode = 404,
                    Message = "User Not Found"
                });
            }
            else
            {
                _Context.Remove(user);
                _Context.SaveChanges();
                return Ok(new
                {
                    StatusCode = 200,
                    Message = "User deleted Successfully"
                });

            }

        }

        [HttpPut("get_userinforecord")]

        public IActionResult GetUserInfoRecord()
        {
            var userinfo = _Context.UserInfoRecordModels.AsQueryable();
            return Ok(new
            {
                StatusCode = 200,
                UserDetails = userinfo
            });
        }

        [HttpPut("get_user/id")]

        public IActionResult GetUser(int id)
        {
            var userRec = _Context.UserInfoRecordModels.Find(id);

            if (userRec == null)
            {
                return NotFound(new
                {
                    StatusCode = 404,
                    Message = "User Not Found"
                });
            }
            else 
            {
                return Ok(new
                {
                    StatusCode = 200,
                    UserDetails = userRec
                });
            }

        }
    }
}
